first create a folder

inside this folder 
git config --global user.name "root"
git config --global user.email "root@gmail.com"


Initialization -> git init

Adding a file to -> git add File_name

Commiting a FIle -> git commit -m 'File_name.extension'

check the file updates -> git diff

deleting the file -> git rm 'file_name.extension'


create a file and type everything

q -> close without saving
wq -> close with saving

cat