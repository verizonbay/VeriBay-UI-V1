import React from 'react' 

export default class Logout extends React.Component {
    
    componentDidMount(){
        localStorage.removeItem("userData")
        window.location = "/"
    }

    render(){
        return null
    }
}