import React from 'react'
import Delivery from './Delivery';

export default class Payment extends React.Component {

    constructor(){
        super()
        this.state = {
            showDelivery:false
        }
    }

    goToDelivery = () => {
        this.setState({
            showDelivery: true
        })
    }

    render() {

        let payment = <div>Payment
                            <button className="btn btn-outline-primary" onClick={this.goToDelivery}>PAY</button>
                       </div>

        return (
            <div>
                 {(this.state.showDelivery)?<Delivery />:payment}
            </div>
        )
    }
}