import React from 'react'
import Joi from 'joi-browser'
import axios from 'axios'

import Form from '../common/Form';

export default class Register extends Form {

    state = {
        data: {   
                username: "",
                password: "",
                email:"",
                address:"",
                city:"",
            },
        errors: {}
        }

    schema = {
        username: Joi.string().required().label("Username"),
        email: Joi.string().required().label("Email Id"),
        password: Joi.string().required().label("Password"),
        address: Joi.string().required().label("Address"),
        city: Joi.string().required().label("City")
    }


    validate = () => {

        const options = { abortEarly: false }
        const { error } = Joi.validate(
            { email: this.state.email,
              password: this.state.password ,
              city: this.state.city,
              address: this.state.address,
              username: this.state.username
            }, this.schema, options
        )

        if (!error) return null;

        const errors = {}
        for (let item of error.details)
            errors[item.path[0]] = item.message

        console.log(errors)
        return errors

    }


    doSubmit = () => {

        const user = {
            username: this.state.username,
            email: this.state.email,
            password: this.state.password,
            address: this.state.address,
            city:this.state.city
        }

        axios.post("http://192.168.20.121:8098/registerUser",user)
            .then(response => console.log(response))
            .catch(error => console.log(error))

            alert("Registered Successfully")
        window.location = "/"
    }



    render() {
        return (
            <React.Fragment>
                <div>
                    <h1>Register</h1>
                    <form onSubmit={this.submitLoginForm}>
                        {this.renderInput({ name: "username", label: "Username", labelName: "Username", type: "text", placeholder:"User Name" })}
                        {this.renderInput({ name: "email", label: "Email ID", labelName: "Email-ID", type: "email", placeholder:"Email ID" })}
                        {this.renderInput({ name: "password", label: "Password", labelName: "Password", type: "password", placeholder:"Password" })}
                        {this.renderInput({ name: "address", label: "Address", labelName: "Address", type: "text", placeholder:"Address" })}
                        {this.renderInput({ name: "city", label: "City", labelName: "City", type: "text", placeholder:"City"})}
                        {this.renderButton("Register")}
                    </form>
                </div>
            </React.Fragment>
        )
    }
}