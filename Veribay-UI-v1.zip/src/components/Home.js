import React from 'react'
import ProductsView from './ProductsView';

export default class Home extends React.Component {
    render(){
        return(
            <ProductsView />
        )
    }
}