package com.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.service.MyService;

import java.util.List;

import com.test.model.Sample;
import com.test.model.Students;

@RestController
public class AppController {

	@Autowired
	private MyService service;
	
	@RequestMapping("/all")
	public List<Sample> getAll(){
		return service.getAll();
	}
}
