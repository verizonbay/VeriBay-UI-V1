package com.test.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.repo.MyRepo;
import com.test.model.Sample;
import com.test.model.Students;

@Service
public class MyService {

	@Autowired
	private MyRepo repo;

	public List<Sample> getAll() {
		return repo.findAll();
	}
}
