package com.test.repo;

import java.util.UUID;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import com.test.model.Sample;
import com.test.model.Students;

@Repository
public interface MyRepo extends CassandraRepository<Sample, UUID> {}
